import React from 'react'
import Header from './Header' 
import { Link } from 'react-router-dom'

const AddOnsHistory = () => {
  return (
    <div id="wrapper">
        <Header /> 
        <div className="content-page">
            <div className="content"> 
                <div className="container-fluid"> 
                    <div className="row">
                        <div className="col-12">
                            <div className="page-title-box"> 
                                <h4 className="page-title">Add-Ons</h4>
                            </div>
                        </div>
                    </div>                     
                    <div className="row">
                        <div className="col-lg-12">
                            <div class="card">
                                <div class="card-body">                                        
                                    <h4 class="page-title">Add-Ons Purchase History</h4>
                                    <hr class="mb-0"/>
                                    <div class="row">
                                        <div class="table-responsive">
                                            <table id="basic-datatable_wrapper" class="table dt-responsive nowrap w-100 dataTable dtr-inline">
                                                <thead class="table-light">                                                            							
                                                    <tr>
                                                        <th>SL</th>
                                                        <th>Service</th>
                                                        <th>Start Date</th>    
                                                        <th>End Date</th>    
                                                        <th>Status</th>      
                                                        <th>Payment Status</th>                                                      
                                                    </tr>
                                                </thead> 
                                                <tbody>
                                                    <tr>
                                                        <td>1.</td>
                                                        <td>Website Maintenance</td>
                                                        <td>12 June 2023</td>
                                                        <td>12 June 2024</td>  
                                                        <td><label class="badge badge-soft-success">Active</label></td> 
                                                        <td><label class="badge badge-soft-success">Success</label></td> 
                                                    </tr>
                                                    <tr>
                                                        <td>2.</td>
                                                        <td>Website Maintenance</td>
                                                        <td>12 June 2023</td>
                                                        <td>12 June 2024</td>  
                                                        <td><label class="badge badge-soft-warning">Inactive</label></td> 
                                                        <td><label class="badge badge-soft-danger">Failed</label></td> 
                                                    </tr>
                                                </tbody>
                                            </table> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> 
                    </div> 
                </div>
            </div> 
        </div> 
    </div>
  )
}

export default AddOnsHistory